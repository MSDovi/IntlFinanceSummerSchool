function OLSout = OLSmodel(y,x,det)
% =======================================================================
% OLS regression
% =======================================================================
% OLSout = OLSmodel(y,x,det)
% -----------------------------------------------------------------------
% INPUT
%   - y: dependent variable vector    (nobs x 1)
%   - x: independent variables matrix (nobs x nvar)
%
% OPTIONAL INPUT
%   - det: 0 no const; 1 const ; 2 const&trend; 3 const&trend^2; (dflt = 1)
%
% OUPUT
%   - OLSout.meth : 'ols'
%   - OLSout.beta : bhat     (nvar x 1)
%   - OLSout.tstat: t-stats  (nvar x 1)
%   - OLSout.bstd : std deviations for bhat (nvar x 1)
%   - OLSout.yhat : yhat     (nobs x 1)
%   - OLSout.resid: residuals (nobs x 1)
%   - OLSout.sige : e'*e/(n-k)   scalar
%   - OLSout.rsqr : rsquared     scalar
%   - OLSout.rbar : rbar-squared scalar
%   - OLSout.dw   : Durbin-Watson Statistic
%   - OLSout.nobs : nobs
%   - OLSout.nvar : nvars
%   - OLSout.y    : y data vector (nobs x 1)
%   - OLSout.bint : (nvar x2 ) vector with 95% confidence intervals on beta
% =======================================================================
% Ambrogio Cesa Bianchi, March 2015
% ambrogio.cesabianchi@gmail.com

% This script is based on ols.m script by James P. LeSage

if isempty(x)
    [nobs, ~] = size(y);
    nvar = 0;
else
    [nobs, nvar] = size(x); 
    [nobs2, ~] = size(y);
    if (nobs ~= nobs2); error('x and y must have same # obs'); end
end

% Check if ther are constant, trend, both, or none
if ~exist('det','var')
    det = 1;
end

%X Add constant or trend if needed
if det==1 %constant
    x = [ones(nobs,1) x];
    nvar = nvar+1;
elseif det==2 % time trend and constant
    trend = 1:nobs;
    x = [ones(nobs,1) trend' x];
    nvar = nvar+2;
elseif det==3 % time trend, trend^2, and constant
    trend = 1:nobs;
    x = [ones(nobs,1) trend' trend'.^2 x];
    nvar = nvar+3;
end

OLSout.meth = 'ols';
OLSout.y = y;
OLSout.x = x;
OLSout.nobs = nobs;
OLSout.nvar = nvar;

if nobs < 10000
  [~, r] = qr(x,0);
  xpxi = (r'*r)\eye(nvar);
else
  xpxi = (x'*x)\eye(nvar);
end;

OLSout.beta = xpxi*(x'*y);
OLSout.yhat = x*OLSout.beta;
OLSout.resid = y - OLSout.yhat;
sigu = OLSout.resid'*OLSout.resid;
OLSout.sige = sigu/(nobs-nvar);
tmp = (OLSout.sige)*(diag(xpxi));
sigb=sqrt(tmp);
OLSout.bstd = sigb;
tcrit=-tdis_inv(.025,nobs);
OLSout.bint=[OLSout.beta-tcrit.*sigb, OLSout.beta+tcrit.*sigb];
OLSout.tstat = OLSout.beta./(sqrt(tmp));
ym = y - mean(y);
rsqr1 = sigu;
rsqr2 = ym'*ym;
OLSout.rsqr = 1.0 - rsqr1/rsqr2; % r-squared
rsqr1 = rsqr1/(nobs-nvar);
rsqr2 = rsqr2/(nobs-1.0);
if rsqr2 ~= 0
    OLSout.rbar = 1 - (rsqr1/rsqr2); % rbar-squared
else
    OLSout.rbar = OLSout.rsqr;
end;
ediff = OLSout.resid(2:nobs) - OLSout.resid(1:nobs-1);
OLSout.dw = (ediff'*ediff)/sigu; % durbin-watson

% F-test
if det>0
    fx = x(:,1); 
    fxpxi = (fx'*fx)\eye(1);
    fbeta = fxpxi*(fx'*y);
    fyhat = fx*fbeta;
    fresid = y - fyhat;
    fsigu = fresid'*fresid;
    fym = y - mean(y);
    frsqr1 = fsigu;
    frsqr2 = fym'*fym;
    frsqr = 1.0 - frsqr1/frsqr2; % r-squared
    OLSout.F = ((frsqr-OLSout.rsqr)/(1-nvar)) / ((1-OLSout.rsqr)/(nobs-nvar));
end
