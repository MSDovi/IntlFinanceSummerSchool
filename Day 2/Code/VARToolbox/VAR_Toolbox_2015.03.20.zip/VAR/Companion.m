function Fcomp = Companion(F,c_case)
% =======================================================================
% Compute IRFs for a VAR model estimated with VARmodel. Three
% identification schemes can be specified: zero short-run restrictions,
% zero long run restrictions, and sign restrictions
% =======================================================================
% [IRF IRF_opt] = VARir(VAR,nsteps,ident,impact)
% -----------------------------------------------------------------------
% INPUT
%   - VAR     : structure, result of VARmodel function
%   - nsteps  : number of nsteps to compute the IRFs
%
% OPTIONAL INPUT
%   - ident   : type of identification--> 'oir' (default) for zero 
% 
% OUTPUT
%   - IRF(t,j,k) : matrix with 't' steps, the IRF of the 'j' variable for 
% =======================================================================
% Ambrogio Cesa Bianchi, July 2014
% ambrogio.cesabianchi@gmail.com

% Note. This code follows the notation as in the lecture notes available at
% https://sites.google.com/site/ambropo/MatlabCodes

% Reduced form VAR    -->  Y = F*Y(-1) + u
% Structural form VAR --> AY = B*Y(-1) + e     
% Where:
% F = invA*B 
% u = invA*e
% Impulse responses:
% IRF(1) = invA*e          where "e" is impulse in the code
% IRF(j) = H(j)*IRF(1)     where H(j)=H^j and for j=2,...,nsteps



%% Check inputs
%===============================================
if ~exist('c_case','var')
    c_case = 0;
end
if size(F,2)/size(F,1)<1
    F = F';
end

%% Retrieve parameters and preallocate variables
%===============================================
F = F(:,1+c_case:end);
nvar = size(F,1);
nlags = size(F,2)/size(F,1);
Fcomp = [F(:,1:nvar*nlags) ; eye(nvar*(nlags-1)) zeros(nvar*(nlags-1),nvar)];
