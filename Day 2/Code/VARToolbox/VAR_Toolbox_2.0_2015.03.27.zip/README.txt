These codes are for explanatory purposes and may contain bugs or errors.

If you find any bugs or want to give me comments and suggestions you can email me at:
ambrogio.cesabianchi@gmail.com

If you happen to use these codes for research papers can you please quote as follows: 
Ambrogio Cesa-Bianchi, 2015. "VAR Toolbox", sites.google.com/site/ambropo/".